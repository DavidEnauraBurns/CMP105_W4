#include "Player.h"
#include "Framework/Input.h"

Player::Player()
{
}

Player::~Player()
{

}

void Player::handleInput(float dt)
{

	// Up
	if (input->isKeyDown(sf::Keyboard::W)) 
	{ 
		velocity.y = -200.f;
	}
	// Down
	else if (input->isKeyDown(sf::Keyboard::S)) 
	{ 
		velocity.y = 200.f;
	}
	// Left
	else if (input->isKeyDown(sf::Keyboard::A))
	{
		velocity.x = 200.f;
	}
	// Right
	else if (input->isKeyDown(sf::Keyboard::D))
	{
		velocity.x = -200.f;
	}
}


